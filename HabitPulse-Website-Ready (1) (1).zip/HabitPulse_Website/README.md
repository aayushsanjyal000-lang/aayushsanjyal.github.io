# HabitPulse

A desktop-first habit tracker website.

## Run locally
Open `index.html` in Chrome or Edge.

## Publish with GitHub Pages
1. Create a GitHub repository named `HabitPulse`.
2. Upload the contents of this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. GitHub Pages will publish the site at `https://YOUR-USERNAME.github.io/HabitPulse/`.

GitHub Pages supports static HTML, CSS and JavaScript sites and looks for `index.html` as the entry file.
